<?php
// config.example.php - modelo seguro (não contém senhas)

return [
    'db' => [
        'host' => 'localhost',
        'dbname' => 'doc_manager',
        'user' => 'SEU_USUARIO_AQUI',
        'pass' => 'SUA_SENHA_AQUI',
        'charset' => 'utf8mb4',
    ],
];
