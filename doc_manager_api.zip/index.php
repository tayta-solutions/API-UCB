<?php
// index.php - Arquivo principal da API
echo json_encode(["message" => "API carregada"]);
